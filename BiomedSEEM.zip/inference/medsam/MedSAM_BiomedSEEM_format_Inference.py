# -*- coding: utf-8 -*-
# %% load environment
import numpy as np
import matplotlib.pyplot as plt
import os

join = os.path.join
import torch
from segment_anything import sam_model_registry
from skimage import io, transform
import torch.nn.functional as F
import argparse

import pandas as pd
import json
import cv2
import torch.multiprocessing as mp
from tqdm import tqdm
from collections import OrderedDict
# %%

# visualization functions
# source: https://github.com/facebookresearch/segment-anything/blob/main/notebooks/predictor_example.ipynb
# change color to avoid red and green
def show_mask(mask, ax, random_color=False):
    if random_color:
        color = np.concatenate([np.random.random(3), np.array([0.6])], axis=0)
    else:
        color = np.array([251 / 255, 252 / 255, 30 / 255, 0.6])
    h, w = mask.shape[-2:]
    mask_image = mask.reshape(h, w, 1) * color.reshape(1, 1, -1)
    ax.imshow(mask_image)


def show_box(box, ax):
    x0, y0 = box[0], box[1]
    w, h = box[2] - box[0], box[3] - box[1]
    ax.add_patch(
        plt.Rectangle((x0, y0), w, h, edgecolor="blue", facecolor=(0, 0, 0, 0), lw=2)
    )


@torch.no_grad()
def medsam_inference(medsam_model, img_embed, box_1024, H, W):
    box_torch = torch.as_tensor(box_1024, dtype=torch.float, device=img_embed.device)
    if len(box_torch.shape) == 2:
        box_torch = box_torch[:, None, :]  # (B, 1, 4)

    sparse_embeddings, dense_embeddings = medsam_model.prompt_encoder(
        points=None,
        boxes=box_torch,
        masks=None,
    )
    low_res_logits, _ = medsam_model.mask_decoder(
        image_embeddings=img_embed,  # (B, 256, 64, 64)
        image_pe=medsam_model.prompt_encoder.get_dense_pe(),  # (1, 256, 64, 64)
        sparse_prompt_embeddings=sparse_embeddings,  # (B, 2, 256)
        dense_prompt_embeddings=dense_embeddings,  # (B, 256, 64, 64)
        multimask_output=False,
    )

    low_res_pred = torch.sigmoid(low_res_logits)  # (1, 1, 256, 256)

    low_res_pred = F.interpolate(
        low_res_pred,
        size=(H, W),
        mode="bilinear",
        align_corners=False,
    )  # (1, 1, gt.shape)
    low_res_pred = low_res_pred.squeeze().cpu().numpy()  # (256, 256)
    medsam_seg = (low_res_pred > 0.5).astype(np.uint8)
    return medsam_seg

def load_mask_stats(mask_stats_path):
    '''
    Load mask statistics from csv file of columns: split,fname,original_shape,mask_area,mask_bbox
    return a dict of split: {fname: {original_shape: (H,W), mask_area: int, mask_bbox: [x0,y0,x1,y1]}}
    '''
    df = pd.read_csv(mask_stats_path)
    df['mask_bbox'] = df['mask_bbox'].apply(lambda x: eval(x))
    df['original_shape'] = df['original_shape'].apply(lambda x: eval(x))
    df['mask_area'] = df['mask_area'].apply(lambda x: int(x))
    df = df.set_index(['split', 'fname'])
    mask_stats = df.to_dict(orient='index')
    return mask_stats

def dice_multi_class(preds, targets):
    smooth = 1.0
    assert preds.shape == targets.shape
    labels = np.unique(targets)[1:]
    dices = []
    for label in labels:
        pred = preds == label
        target = targets == label
        intersection = (pred * target).sum()
        dices.append((2.0 * intersection + smooth) / (pred.sum() + target.sum() + smooth))
    return np.mean(dices)

def dice_binary(preds, targets, smooth=1.0):
    assert preds.shape == targets.shape
    pred = preds == 1  # Assuming the foreground class is labeled as 1
    target = targets == 1
    intersection = (pred * target).sum()
    return (2.0 * intersection + smooth) / (pred.sum() + target.sum() + smooth)
# %% load model and image
parser = argparse.ArgumentParser(
    description="run inference on testing set based on MedSAM"
)
parser.add_argument(
    "-i",
    "--data_path",
    type=str,
    default="assets/img_demo.png",
    help="path to the data folder",
)
parser.add_argument("--device", type=str, default="cuda:0", help="device")
parser.add_argument(
    "-chk",
    "--checkpoint",
    type=str,
    default="work_dir/MedSAM/medsam_vit_b.pth",
    help="path to the trained model",
)
parser.add_argument("--mask_stats_path", type=str, default="assets/mask_stats.json")
parser.add_argument("--data_dir", type=str, default="assets/")
parser.add_argument("--num_workers", type=int, default=20)
args = parser.parse_args()
# args = parser.parse_args('--data_dir /mnt/hanoverdev/data/BiomedSeg/COVID-QU-Ex  --device cuda:0 --checkpoint /mnt/hanoverdev/models/BiomedSEEM/medsam/medsam_vit_b.pth'.split())

device = args.device
medsam_model = sam_model_registry["vit_b"](checkpoint=args.checkpoint)
medsam_model = medsam_model.to(device)
medsam_model.eval()


# %%

def MedSAM_infer_BiomedSEEM_format(gt_path_file, bbox_shift=20):
    ''' 
    - mask_stats: pandas dataframe of: split,fname,original_shape,mask_area,mask_bbox. Mask_bbox is a list of 4 numbers: [x_top_left, y_top_left, x_bottom_right, y_bottom_right]
    - folder test: original images in .png format
    - folder test_mask: ground truth masks in .png format
    - objective: 1. generate folder test_mask_medsam: segmentation results in .png format; 2. compute dice score for each image, following the calculation in MedSAM_infer_npz
    '''
    gt_path = os.path.join(gt_dir, gt_path_file)
    image_name = '_'.join(gt_path.split('/')[-1].split('_')[:-1])
    image_path = os.path.join(image_dir, image_name + '.png')
    # todo: confirm how gt is loaded
    # load ground truth
    gt = io.imread(gt_path, as_gray=True)
    # Load the image
    img_np = io.imread(image_path)

    # Convert to 3-channel if necessary
    if len(img_np.shape) == 2:  # Grayscale image
        img_3c = np.repeat(img_np[:, :, None], 3, axis=2)
    elif img_np.shape[2] == 4:  # RGBA image, remove alpha channel
        img_3c = img_np[:, :, :3]
    else:
        img_3c = img_np 

    # Image preprocessing
    H, W, _ = img_3c.shape
    img_1024 = transform.resize(
        img_3c, (1024, 1024), order=3, preserve_range=True, anti_aliasing=True
    ).astype(np.uint8)
    img_1024 = (img_1024 - img_1024.min()) / np.clip(
        img_1024.max() - img_1024.min(), a_min=1e-8, a_max=None
    )  # normalize to [0, 1], (H, W, 3)
    # convert the shape to (3, H, W)
    img_1024_tensor = (
        torch.tensor(img_1024).float().permute(2, 0, 1).unsqueeze(0).to(device)
    )
    gt_1024 = cv2.resize(gt, (1024, 1024), interpolation=cv2.INTER_NEAREST) # (1024, 1024) following the original code
    # todo: two sources of box, one from mask_stats, one from gt
    y_indices, x_indices = np.where(gt_1024 > 0)
    x_min, x_max = np.min(x_indices), np.max(x_indices)
    y_min, y_max = np.min(y_indices), np.max(y_indices)
    # add perturbation to bounding box coordinates
    x_min = max(0, x_min - bbox_shift)
    x_max = min(W, x_max + bbox_shift)
    y_min = max(0, y_min - bbox_shift)
    y_max = min(H, y_max + bbox_shift)
    box_1024 = np.array([[x_min, y_min, x_max, y_max]])

    # # Scale bounding box to match the resized image
    # box_1024 = np.array(box) / np.array([W, H, W, H]) * 1024

    # Inference
    with torch.no_grad():
        image_embedding = medsam_model.image_encoder(img_1024_tensor)
    medsam_seg = medsam_inference(medsam_model, image_embedding, box_1024, H, W)

    os.makedirs(seg_dir, exist_ok=True)
    output_filename = "seg_" + os.path.basename(gt_path)
    io.imsave(os.path.join(seg_dir, output_filename), medsam_seg*255, check_contrast=False) # save as 0-255


    dice = dice_binary(medsam_seg, gt)
    return os.path.basename(gt_path), dice
# %%
# load mask stats
data_dir = args.data_dir
if not os.path.exists(os.path.join(data_dir, 'mask_stats.csv')):
    mask_stats_path = os.path.join(os.path.basedir(data_dir), 'mask_stats.csv')
else:
    mask_stats_path = os.path.join(data_dir, 'mask_stats.csv') 
image_dir = os.path.join(data_dir, 'test')
gt_dir = os.path.join(data_dir, 'test_mask')
seg_dir = os.path.join(data_dir, 'test_mask_medsam')

mask_stats = load_mask_stats(mask_stats_path) # dict of split: {fname: {original_shape: (H,W), mask_area: int, mask_bbox: [x0,y0,x1,y1]}}
gt_path_files = sorted([f for f in os.listdir(gt_dir) if f.endswith('.png')])


#%%
dice_dict = OrderedDict()
dice_dict['image'] = []
dice_dict['dice'] = []

# %%
if __name__ == '__main__':
    print('find {} ground truth files'.format(len(gt_path_files)))
    num_workers = args.num_workers
    mp.set_start_method('spawn')
    with mp.Pool(processes=num_workers) as pool:
        with tqdm(total=len(gt_path_files)) as pbar:
            for i, (name, dice) in tqdm(enumerate(pool.imap_unordered(MedSAM_infer_BiomedSEEM_format, gt_path_files))):
                pbar.update()
                dice_dict['image'].append(name)
                dice_dict['dice'].append(np.round(dice, 4))

    dice_df = pd.DataFrame(dice_dict)
    dice_df.sort_values(by=['image'], ascending=True, inplace=True)
    print(dice_df)
    # save dice_df
    dice_df.to_csv(os.path.join(data_dir, 'test_medsam_dice.csv'), index=False)
# %%
