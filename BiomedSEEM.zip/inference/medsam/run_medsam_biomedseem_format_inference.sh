#!/bin/bash
# run inference on biomedseem datasets
# data_list=('ACDC' 'AbdomenCT-1K' 'BreastCancerCellSegmentation' 'BreastUS' 'CAMUS' 'CDD-CESM' 'COVID-QU-Ex' 'CXR_Masks_and_Labels' 'FH-PS-AOP' 'G1020' 'GlaS' 'ISIC' 'LGG' 'LIDC-IDRI' 'MMs' 'NeoPolyp' 'OCT-CME' 'PROMISE12' 'PolypGen' 'QaTa-COV19' 'REFUGE' 'UWaterlooSkinCancer' 'kits23' 'siim-acr-pneumothorax')
data_list=( 'MSD/Task03_Liver' 'MSD/Task06_Lung' 'MSD/Task09_Spleen' 'MSD/Task04_Hippocampus' 'MSD/Task07_Pancreas' 'MSD/Task10_Colon' 'MSD/Task02_Heart' 'MSD/Task05_Prostate' 'MSD/Task08_HepaticVessel' 'Radiography/COVID' 'Radiography/Lung_Opacity' 'Radiography/Normal' 'Radiography/Viral_Pneumonia')
# loop to inference on all datasets
for data in "${data_list[@]}"; do
    # Assuming python is the correct interpreter; adjust if needed
    echo "processing $data"
    python MedSAM_BiomedSEEM_format_Inference.py --data_dir "/mnt/hanoverdev/data/BiomedSeg/$data" --checkpoint "/mnt/hanoverdev/models/BiomedSEEM/medsam/medsam_vit_b.pth" --num_workers 20
done