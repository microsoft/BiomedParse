# hacky scripts to postprocess the results of the experiments
# %%
import os
import json
import numpy as np
import pandas as pd
from biomed_meta import BIOMED_CATEGORIES

# %%
class BiomedSEEMPostprocess:
    """
    Postprocess the results of BiomedSEEM experiments.
    """
    def __init__(self, result_path):
        self.result_path = result_path
        self.results = self.load_results(result_path)
        self.instance_results = self.extract_instance_results(self.results)
    
    def load_results(self, result_path):
        with open(result_path, 'r') as f:
            results = json.load(f)
        return results
    
    def extract_instance_results(self, results):
        """
        Extract instance results from the results and convert them to a list of dictionaries.
        """
        lines = []
        for dataset_name, dataset_results in results.items():
            for evaluator_type, evaluator_results in dataset_results.items():
                instance_results = evaluator_results['instance_results']
                for instance in instance_results:
                    assert len(instance['Dice']) == len(instance['IoU'])
                    for batch_id in range(len(instance['IoU'])):
                        lines.append({
                            'dataset_name': dataset_name,
                            'evaluator_type': evaluator_type,
                            'metadata': instance['metadata'],
                            'category_id': instance['metadata']['grounding_info'][batch_id]['category_id'],
                            'IoU': instance['IoU'][batch_id],
                            'Dice': instance['Dice'][batch_id],
                            'I': instance['I'][batch_id],
                            'U': instance['U'][batch_id],
                            'pred_area': instance['pred_area'][batch_id] if 'pred_area' in instance else '',
                        })
        return lines
    
    def compute_mean_IoU(self, results):
        """
        Compute mean IoU from the results.
        """
        # IoUs = [result['IoU'] for result in results]
        # return 100*np.mean(IoUs)
        Is = [result['I'] for result in results]
        Us = [result['U'] for result in results]
        IOUs = [I / (U + 1e-9) for I, U in zip(Is, Us)]
        return 100*np.mean(IOUs)
    
    def compute_mean_Dice(self, results):
        """
        Compute mean Dice from the results.
        """
        Dices = [result['Dice'] for result in results]
        return 100*np.mean(Dices)
    
    def compute_cum_IoU(self, results):
        """
        Compute cumulative IoU from the results.
        """
        Is = [result['I'] for result in results]
        Us = [result['U'] for result in results]
        return 100* np.sum(Is) / (np.sum(Us) + 1e-9)
    
    def compute_cum_Dice(self, results):
        """
        Compute cumulative Dice from the results.
        """
        Is = [result['I'] for result in results]
        Us = [result['U'] for result in results]
        return 100 * np.sum(Is) * 2 / (np.sum(Is) + np.sum(Us) + 1e-9)
    
    def convert_to_csv(self, final_results):

        def remove_key_and_flatten(dictionary, key_to_remove):
            new_dict = {}
            for key, value in dictionary.items():
                if key == key_to_remove and isinstance(value, dict):
                    new_dict.update(value)
                elif isinstance(value, dict):
                    new_dict[key] = remove_key_and_flatten(value, key_to_remove)
                else:
                    new_dict[key] = value
            return new_dict
        updated_dataset_level_dict = remove_key_and_flatten(final_results['dataset_level'], 'grounding')
        updated_category_level_dict = remove_key_and_flatten(final_results['category_level'], 'grounding')
        # round the scores
        pd.DataFrame(updated_dataset_level_dict).T.round(2).to_csv(os.path.join(os.path.dirname(self.result_path), 'dataset_level.csv'))
        pd.DataFrame(updated_category_level_dict).T.round(2).to_csv(os.path.join(os.path.dirname(self.result_path), 'category_level.csv'))
        


    def calc_scores(self, results):
        return {
            'cum_IoU': self.compute_cum_IoU(results),
            'mean_IoU': self.compute_mean_IoU(results),
            'cum_Dice': self.compute_cum_Dice(results),
            'mean_Dice': self.compute_mean_Dice(results),
        }

    def postproces(self):
        """
        return scores of : per dataset, per category, per evaluator
        """
        dataset_names = list(self.results.keys())
        evaluator_types = self.results[dataset_names[0]].keys()
        # aggregate results per dataset
        dataset_scores = {}
        for dataset_name in dataset_names:
            lines = [line for line in self.instance_results if line['dataset_name'] == dataset_name]
            if len(lines) == 0:
                continue
            dataset_scores[dataset_name] = {}
            for evaluator_type in evaluator_types:
                dataset_scores[dataset_name][evaluator_type] = self.calc_scores(lines)
        # aggregate results per category
        category_scores = {}
        for category_id in range(len(BIOMED_CATEGORIES)):
            lines = [line for line in self.instance_results if line['category_id'] == category_id]
            if len(lines) == 0:
                continue
            category_name = BIOMED_CATEGORIES[category_id-1]
            category_scores[category_name] = {}
            for evaluator_type in evaluator_types:
                category_scores[category_name][evaluator_type] = self.calc_scores(lines)
        # aggregate results per dateset and category
        dataset_category_scores = {}
        for dataset_name in dataset_names:
            dataset_category_scores[dataset_name] = {}
            for category_id in range(len(BIOMED_CATEGORIES)):
                lines = [line for line in self.instance_results if line['dataset_name'] == dataset_name and line['category_id'] == category_id]
                if len(lines) == 0:
                    continue
                category_name = BIOMED_CATEGORIES[category_id-1]
                dataset_category_scores[dataset_name][category_name] = {}
                for evaluator_type in evaluator_types:
                    dataset_category_scores[dataset_name][category_name][evaluator_type] = self.calc_scores(lines)
        # save results
        final_results = {
                'dataset_level': dataset_scores,
                'category_level': category_scores,
                'dataset_category_level': dataset_category_scores,
            }
        with open(os.path.join(os.path.dirname(self.result_path), 'postprocessed_results.json'), 'w') as f:
            json.dump(final_results, f, indent=4)
        # convert to csv and save
        self.convert_to_csv(final_results)
        return final_results
        
# %%
# test
# postprocessor = BiomedSEEMPostprocess('/home/yugu1/repos/BiomedSEEM/output/biomed_seem_lang_v1.yaml_conf~/run_49/eval_results.json')
# final_results = postprocessor.postproces()
# %%

# def remove_key_and_flatten(dictionary, key_to_remove):
#     new_dict = {}
#     for key, value in dictionary.items():
#         if key == key_to_remove and isinstance(value, dict):
#             new_dict.update(value)
#         elif isinstance(value, dict):
#             new_dict[key] = remove_key_and_flatten(value, key_to_remove)
#         else:
#             new_dict[key] = value
#     return new_dict
# updated_dict = remove_key_and_flatten(final_results['dataset_category_level'], 'grounding')
# pd.DataFrame(updated_dict).T
# %%
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('result_path', type=str, help='path to the result file to be postprocessed')
    args = parser.parse_args()
    postprocessor = BiomedSEEMPostprocess(args.result_path)
    postprocessor.postproces()
