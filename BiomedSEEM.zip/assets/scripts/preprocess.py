import json
import os
f = "amos22/MRI"
for split in ['train', 'test']:
    file = f"/mnt/hanoverdev/data/med_seem/SEEM_format/{f}/{split}.json"
    #file = "/mnt/hanoverdev/data/med_seem/SEEM_format/REFUGE/train.json"
    data = json.load(open(file, 'r'))

    empty_anns = [ann for ann in data['annotations'] if ann['segmentation'] == []]
    print(empty_anns)
    data['annotations'] = [ann for ann in data['annotations'] if len(ann['segmentation']) > 0]
    
    imgs = [img['file_name'] for img in data['images']]

    images_with_ann = set()
    for ann in data['annotations']:
        images_with_ann.add(ann['file_name'])
        if ann['file_name'] not in imgs:
            print(ann['file_name'], 'not in images')
        
    print([img for img in data['images'] if img["file_name"] not in images_with_ann])
    
    if len(empty_anns) > 0 or len([img for img in data['images'] if img["file_name"] not in images_with_ann]) > 0:
        fix = True
        print('Fixing missing annotations...')
    else:
        fix = False

    data['images'] = [img for img in data['images'] if img["file_name"] in images_with_ann]

    img_path = file.split('.')[0]
    img_files = os.listdir(img_path)
    for img in images_with_ann:
        if img not in img_files:
            print(img, 'not in', img_path)

    if not fix:
        continue
    
    json.dump(data, open(file, 'w'))

    for f2 in img_files:
        if f2 not in [i['file_name'] for i in data['images']]:
            print(f2, 'removed')
            os.remove(os.path.join(img_path, f2))
            os.remove(os.path.join(img_path + '_mask', f2))
            
    