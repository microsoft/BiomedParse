from the project root dir

bash docker/docker_build.sh

bash docker_run.sh to start

inside docker container, run setup_inside_docker.sh