# *BiomedParse:* 
Welcome to BiomedParse! We provide test training and evaluation using sample datasets here. Follow the instructions to run the code. You will first need to set up the environment using docker. Then put pretreined models and example data under the projected directory. Finally you can train and evaluation model with a simple line of command. 


Install docker
```
sudo apt update
sudo apt install apt-transport-https ca-certificates curl software-properties-common
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"
sudo apt update
apt-cache policy docker-ce
sudo apt install docker-ce
```



Prepare docker environment:
```sh
bash docker/docker_build.sh
bash docker/docker_run.sh
bash docker/setup_inside_docker.sh
source docker/data_env.sh 
```

Model: Create "pretreined" folder under the project directory. Put pretrained model under the pretreined folder (pretreined/biomed_parse.pt under project directory).

Data: Create "data" folder under the project directory. Unzip the data files under the data folder.

Evaluation on example BioParseData:
```sh
bash assets/scripts/eval.sh
```

You will find your model evaluation run results under the "output" folder. Individual segmentation files will be saved inside each dataset folder under "test_pred".

Continue training using example BioParseData:
```sh
bash assets/scripts/train.sh
```

You will find your model training run results under the "output" folder. 

Training on your own data: 
1. Simply format your data in the same form under the "data" folder.
2. Add the name of your data directory to the datasets list in datasets/registration/register_biomed_datasets.py.
3. Add the name of your data directory to "DATASETS" lists in the config file configs/biomedseg/biomed_seg_lang_v1.yaml.

<!-- BiomedSEEM Evaluation:
SEEM evaluaiton primarily focuses on the dataset level. To extend this evaluation to include category or modality levels, run:

```sh
python assets/scripts/postprocess.py [path to saved file]
```
for example: 
 ```python assets/scripts/postprocess.py output/biomed_seem_lang_v1.yaml_conf~/run_22/eval_results.json``` -->

<!-- This script generate detailed evalluation results in a new file named "postprocessed_results.json". Additionally, it will create two csv files for category and datset level evaluation results respectively. -->
